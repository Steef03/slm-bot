### Steef Le Megalodon Bot V1
   <a><img src='https://telegra.ph/file/542bacd1d546a0b7b8193.jpg'/></a><a><https://telegra.ph/file/542bacd1d546a0b7b8193.jpg'/></a>
<p align="center">
<img src="https://telegra.ph/file/542bacd1d546a0b7b8193.jpg"/> 
<p align="center">
  <a href="https://telegra.ph/file/542bacd1d546a0b7b8193.jpg"><img
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=800&size=28&duration=4000&pause=1000&random=false&width=435&lines=+_____Voltage+V1+BUG+-BOT_____;WHATSAPP+CRASH+x+BUG+BOT;DEVELOPED+BY+MÀYOR;REALESE+DATE+10%2F8%2F2024." alt="Typing SVG" /></a>
</p>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### If you want to deploy somewhere else, upload your creds.json in session folder after getting pair code on replit. 

### 1. <a href="https://github.com/Steef03/slm-bot/fork"><img src="https://img.shields.io/badge/FORK-blue" alt="Click Here to fork Steef Le Megalodon Bot" width="70"></a>
 


### 2.
#### COPY THESE COMMANDS AND PASTE IF YOU TRYING TO DEPLOY [SLM BOT V1](https://github.com/Steef03/slm-bot) ON ANY TERMINAL
```
sudo apt -y update && sudo apt -y upgrade
```
```
sudo apt -y install git ffmpeg curl
```
```
curl -fsSL https://deb.nodesource.com/setup_20.x -o nodesource_setup.sh
```
```
sudo -E bash nodesource_setup.sh
```
```
sudo apt-get install -y nodejs
```
```
sudo npm install -g yarn
```
```
sudo yarn global add pm2
```
```
git clone https://github.com/type-your-username-here/slm-bot 
```
```
cd slm-bot 
yarn install 
npm start
```
 

<a><img src='https://telegra.ph/file/542bacd1d546a0b7b8193.jpg'/></a><a><img src='https://telegra.ph/file/542bacd1d546a0b7b8193.jpg'/></a>
# Termux Deployment
### this code copy from Prexzy  all credits for him

```
atp update
   

apt upgrade

pkg update && pkg upgrade

pkg install bash

 pkg install git

 pkg install nodejs

pkg install ffmpeg

pkg install wget

pkg install imagemagick

 pkg install yarn

termux-setup-storage
```

```
git clone https://github.com/Steef03/slm-bot
```
```
 cd slm-bot
```
```
yarn install
  ```
    
```
npm start
```



<a><img src='https://telegra.ph/file/542bacd1d546a0b7b8193.jpg'/></a><a><img src='https://telegra.ph/file/542bacd1d546a0b7b8193.jpg'/></a>

